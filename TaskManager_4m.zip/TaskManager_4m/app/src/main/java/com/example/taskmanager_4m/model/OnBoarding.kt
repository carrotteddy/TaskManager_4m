package com.example.taskmanager_4m.model


data class OnBoarding(
    val image: String? = null,
    val title: String? = null,
    val desc: String? = null
)
